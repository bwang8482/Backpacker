<?php

//$descriptorspec = array (
//	0 =>array("pipe","r"),
//	1 => array("pipe","w"),
//	2 => array("file","./out.txt","a")
//);
echo exec('./cgi-bin/hello.py');
//$cwd='./';
//$process = proc_open('./cgi-bin/hello.py',$descriptorspec,$pipes,$cwd);
//while(is_resource($process)){	
//	print fgets($pipes[1]);
//	fclose($pipes[1]);
//}
//proc_close($process);
// http://stackoverflow.com/questions/4059117/proc-open-c-python
// http://www.php2python.com/wiki/function.popen/
// http://www.php2python.com/wiki/function.popen/

?>