<?php

	$title = $_POST["title"];
	$content = "a";//$_POST["content"];
	$author = "a";//$_POST["author"];
	$location = $_POST["location"];

	if($location == "undefined") 
		$location = null;

	// $servername = "localhost";
        $servername = "engr-cpanel-mysql.engr.illinois.edu";
        $username= "backpack_zbc";
        $password="123456";
        $dbname="backpack_user";
	$conn = new mysqli($servername, $username, $password, $dbname);

        if($conn->connect_error){
            // echo "database connection failed <br>";
        }

	$cmd = "SELECT * FROM crawled_posts WHERE title = '".$title."'";
	$result = $conn->query($cmd);

        // echo $result->num_rows;

	if($result->num_rows==0){
                // echo "start inserting";
		$cmd = "INSERT INTO crawled_posts(author, location, content, title) VALUES('$author','$location','$content','$title')";
		mysqli_query($conn,$cmd);

	}


	// post_id, author, location, content, title, date

?>