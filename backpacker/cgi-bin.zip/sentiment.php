<?php
include 'Opinion.php';
$op = new Opinion();
$op->addToIndex(__DIR__ . '/rt-polarity.neg', 'neg');
$op->addToIndex(__DIR__ . '/rt-polarity.pos', 'pos');


$text="A few months ago, I read the book Visit Sunny Chernobyl by Andrew Blackwell, about the worst’s biggest garbage-ridden and polluted places. It’s like the anti-travel guide. It’s about all the places a traveler wouldn’t go, the ugly places we overlook. It was interesting to learn about these places that exist but never get any coverage. Smart, funny, and well written, this is one of my favorite books I read all year. Since Andrew lives in NYC, I had the good fortune to get to chat with him recently. Nomadic Matt: Tell everybody about yourself. How did you get into writing? Andrew Blackwell: I got into writing just by being a reader. I was always interested in reading and writing in high school and college, but I had no real professional experience as a print reporter before I wrote the book. My real background was as a documentary editor. But you learn a lot about storytelling and structure through filmmaking. Nomadic Matt: How did you come up with the book idea? I was living and traveling in India for about six months with my girlfriend. She was working for an NGO, and I was traveling around with her to these environmental sites and got to see some quite polluted, not-on-your-regular-tourist-itinerary places. And I really enjoyed them. I thought, “You know, if no one writes the guidebook to polluted places, nobody will know that these places are interesting to visit.” So I had this idea, and it always just kind of kept rattling around in my head. I eventually just really incrementally developed the book proposal and wrote the first chapter on my own really slowly over the course of several years. And then once I had that, I started showing it to agents. And the way it works for nonfiction books, especially if you’re not established, you have to basically write the first chapter first. You have to write a proposal sort of mapping out what the whole thing is. But it was getting a book contract that forced me to really have to go out into the world and do this! Nomadic Matt: When did you actually come up with the idea, and when did you go to Chernobyl, and when did you actually write the book? I had the idea for this book in the spring of 2003. I went to Chernobyl in the spring of 2006. I got the book deal based on the chapter I wrote about Chernobyl, I think, in 2009. And then it was two years of traveling and writing before submitting it to the publisher. It was a real odyssey. Nomadic Matt: Yeah, that’s a long time. How did you pick the places in the book? Well, I wanted to get a good spread of different kinds of environmental issues and different parts of the world, as well as different travel activities. I was thinking about the book not just as an environmental reporter would but also as a travel writer. I didn’t want to be hiking in a forest on every trip. So those were the three criteria: the choice of environmental issue, the geographic location, and the travel angle. For example, you always hear about the garbage patch, but almost no one who writes about it has actually been there, because it’s an incredible pain in the ass to get there. So I thought, “I’ve got to go there.” And that would be the “cruise” chapter.";
$sentences = explode(".", $text);
$score = array('pos' => 0, 'neg' => 0);
foreach($sentences as $sentence) {
        if(strlen(trim($sentence))) {
                $polarity = $op->classify($sentence);
                $score[$polarity]++;
        }
}
var_dump($score);




//$string = "This movie was noting else but a huge disappointment.";
//echo "Classifying '$string' - " . $op->classify($string) . "\n";
//$string = "Twilight was an atrocious movie, filled with stumbling, awful dialogue, and ridiculous story telling.";
//echo "Classifying '$string' - " . $op->classify($string) . "\n";
//$string = "Loving this wheater";
//echo "Classifying '$string' - " . $op->classify($string) . "\n";
?>