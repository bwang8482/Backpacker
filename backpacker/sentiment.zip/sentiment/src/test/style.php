<html>
	<style>
		body
		{
			background-color: #87CEFA;
		}
		table
		{
			border: 1px solid #000;
			width: 80%;
			text-align: center;
			margin-left: 50px;
		}
		#test{
			background-color: #FFDEAD;
			height:490px;
			width: 23%;
			float: left;
			text-align: center;

		}
		#result{
			width: 100%;
			background-color: #E0FFFF;
			height: 260px;
			text-align: left;
		}
		#sentence1{
			background-color: #FFFFE0;
			width: 75%;
			margin-left: 320px;
			height: 200px;
			padding: 10px 0 0 0px;
			text-align: center;
			border-radius: 5px;
			border: 2px solid #20B2AA;
		}
		#sentence2{
			background-color: #FFFACD ;
			width: 75%;
			margin-left: 320px;
			height: 200px;
			padding: 10px 0 0 0px;
			text-align: center;
			border-radius: 5px;
			border: 2px solid #20B2AA;
		}
		#document{
			background-color: #FFFFF0 ;
			width: 75%;
			margin-left: 320px;
			height: 200px;
			padding: 10px 0 0 0px;
			text-align: center;
			border-radius: 5px;
			border: 2px solid #20B2AA;
		}
		#sentence, #location{
			width: 95%;
			height: 40px;
		}
		#goSentence, #goLocation{
			width: 40%;
			height: 20px;
			margin-top: 5px;
		}
		p{
			font-size: 1.2em;
		}
	</style>